import { Component, OnInit } from '@angular/core';
import {HttpService} from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = "Rate Cakes";
  stuff= [];
  details=[];
  newCake:any;
  selectedCake="";
  newReview:any;
  constructor(private _httpService: HttpService){
    this.getCakes();
  }
  getCakes(){
    let tempObservable = this._httpService.getCakes();
    tempObservable.subscribe((data:any)=>{
      this.stuff = data;
    })
  }
  ngOnInit(){
    this.newCake= {baker: "",image:""}
    this.newReview={rating:Number, comment:""}
    this.getCakes();
  }

  // showDetails(id: string){
  //   this.details=[];
  //   for ( var i =0; i < this.stuff.length; i++){
  //     if (this.stuff[i]._id == id){
  //       this.selectedCake=this.stuff[i];
  //       // this.details= this.stuff[i].createdAt;
  //     }
  //   }
  // }

  createCake(){
    console.log('hit create cake component')
    let tempObservable = this._httpService.createCake(this.newCake);
    tempObservable.subscribe(responseData =>{
      console.log(responseData);
      this.newCake = {baker: "",image:""}});
      this.getCakes();
    }
  
    deleteCake(id:string){
      console.log('hit deleteCake in component',id);
      let observable = this._httpService.deleteACake(id);
      observable.subscribe(responseData => {
        console.log(responseData);
        this.getCakes()
      })
    }
    showCake(id:string){
      console.log('hit show cake in component', id);
      let observable = this._httpService.getACake2(id);
      observable.subscribe(responseData => {
        this.selectedCake = "";
        for (var i =0; i < this.stuff.length; i ++){
          if (this.stuff[i]._id == id){
            this.selectedCake= this.stuff[i];
            console.log("selected cake:", this.selectedCake)
          }
        }
        console.log("response data:",responseData);
        this.getCakes()
      })
    }
    addReview(cakeid:string){
      console.log('hit addReview in component, id:', cakeid);
      console.log('data going into service:, ', this.newReview)
      let observable = this._httpService.addReview(cakeid, this.newReview);
      observable.subscribe(responseData =>{
        console.log(responseData)
        this.newReview = {rating:"", comment: ""};
        this.showCake(cakeid);
      })
      this.showCake(cakeid);
    }
  }

