import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  constructor(private _http:HttpClient) {
  }
    getCakes(){
      let tempObservable = this._http.get('/cakes');
      tempObservable.subscribe((data:any) => {
        // console.log('got all the tasks', data)
        for ( var i = 0; i < data.length; i++){
          this.getACake(data[i]._id);
        }
        // return this._http.get('/tasks')
      })
      return tempObservable;
    
    }
    getACake(id: string){
      return this._http.get(`${id}`);
    }
    getACake2(id: string){
      console.log('got cake', id);
      return this._http.get(`${id}`);
    }
    createCake(cakeObj){
      console.log('hit post to server, cakeObj: ', cakeObj);
      return this._http.post(`/newcake`,cakeObj)
    }
    deleteACake(id:string){
        console.log('hit server delete', id);
        return this._http.delete(`/remove/${id}`);
      }
    addReview(cakeid:string, revObj){
      console.log('hit server addReview, id: ', cakeid);
      console.log('data going into route: ', revObj)
      return this._http.put(`/newreview/${cakeid}`,revObj)
    }
  }

